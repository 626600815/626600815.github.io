//
//  MQLog.h
//  QQ4Mac
//
//  Created by pangmengyu on 12-10-9.
//  Copyright (c) 2012年 tencent. All rights reserved.
//

#ifndef QQ4Mac_MQLog_h
#define QQ4Mac_MQLog_h

#import <Cocoa/Cocoa.h>
#import "LoggerClient.h"

#ifdef __DEPLOYMENT
#define MQLog(...) do{}while(0)
#define MQLogTag(tag, level, fmt, arg...) do{}while(0)
#define MQLogTagS(tag, level, fmt, arg...) do{}while(0)
#define MQLogTagD(tag, fmt, arg...) do{}while(0)
#define MQLogTagE(tag, fmt, arg...) do{}while(0)
#define MQTrace do{}while(0)
#define MQTraceLog(...) do{}while(0)
#else
#define MQLog(...) do{LogMessageF(__FILE__,__LINE__,__FUNCTION__,@"MacQQ",4,__VA_ARGS__); NSLog(__VA_ARGS__);}while(0)
#define MQLogTag(tag, level, fmt, arg...) do{LogMessageF(__FILE__,__LINE__,__FUNCTION__, tag, level, fmt,##arg); NSLog(@"%s, %@, %d" fmt, __FUNCTION__,tag,level,##arg);}while(0)
#define MQLogTagS(tag, level, fmt, arg...) do{LogMessageF(__FILE__,__LINE__,__FUNCTION__, tag, level, fmt,##arg);}while(0)
#define MQLogTagD(tag, fmt, arg...) MQLogTag(tag,1,fmt,##arg)
#define MQLogTagE(tag, fmt, arg...) MQLogTag(tag,0,fmt,##arg)
#define MQTrace do{LogMessageF(__FILE__,__LINE__,__FUNCTION__,@"MacQQ",4,@""); NSLog(@"%s", __FUNCTION__);}while(0)
#define MQTraceLog(fmt, arg...) do{LogMessageF(__FILE__,__LINE__,__FUNCTION__,@"MacQQ",4,fmt,##arg); NSLog(@"%s" fmt, __FUNCTION__, ##arg);}while(0)
#endif

#endif
