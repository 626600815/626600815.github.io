/*
 *  report.h
 *  WeiboEngine
 *
 *  Created by Amos.Lan on 1/20/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */
#ifndef _LOGRP_INC_
#define _LOGRP_INC_

#pragma once
#include <stddef.h>
#include <limits.h>

#define UIN_LOGINFAIL 2
#define UIN_AUTO 3
#define UIN_LOGINOK 4

#ifdef __cplusplus
extern "C" {
#endif
    typedef struct _tag_rpt_init_info {
        long dwProductVer;
        long dwLCID;
        char cstrBugRpPath[PATH_MAX];
        char cstrIdentifier[NAME_MAX];
    }tag_rpt_init_info;
    
	typedef void (*fn_onchanged)(bool isok, int percent /*0~100*/);
	
	/* desc		: start reporter daemon
	 * input	:
	 *	onchanged	- function address to handle progress changed
	 * return	:
	 *	return -1 if failed
	 */
	//int		rpt_init(bool bStoreInBundle, const char *relativePath, const char *identifier, fn_onchanged onchanged = NULL);
	//int		rpt_init(const char *crashReportPath, const char *Identifier, fn_onchanged onchanged = NULL);
    int     rpt_init(tag_rpt_init_info &productInfo, fn_onchanged onchanged = NULL);
	/* desc		: start a upload task
	 * input	:
	 *	body	- mail content
	 * return	:
	 *	return -1 if failed
	 */
	int		rpt_send(unsigned long uin, const char* account, const char* body = NULL, const char* file = NULL, const char* hash = NULL);
	
	/* desc		: set report info
	 * input	:
	 *	body	- mail content
	 * return	:
	 *	return -1 if failed
	 */
	int		rpt_setinfo(unsigned long uin, const char* accoount, int uinflag);
	
	/* desc		: stop logreporter daemon and free memory resource
	 */
	void	rpt_terminate(void);
	
#ifdef __cplusplus
};
#endif

#endif /*_LOGRP_INC_*/