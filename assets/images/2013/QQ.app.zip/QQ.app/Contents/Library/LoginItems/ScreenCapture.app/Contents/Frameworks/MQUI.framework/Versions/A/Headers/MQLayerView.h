//
//  MQLayerView.h
//  MacQQ
//
//  Created by zhuochen on 12-8-31.
//  Copyright (c) 2012年 Tencent. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <QuartzCore/QuartzCore.h>

@interface MQLayerView : NSView
{
    
}

- (id) layerClass;
@end
