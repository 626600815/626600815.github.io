//
//  MQPull2RefreshClipView.h
//  QQ4Mac
//
//  Created by Hugoyao on 12-03-09.
//  Copyright (c) 2011年 tencent. All rights reserved.


#import <AppKit/AppKit.h>

@interface MQPull2RefreshClipView : NSClipView

@end
