//
//  kernel.h
//  CFLocalServer
//
//  Created by Admin on 12-10-8.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#ifndef CFLocalServer_kernel_h
#define CFLocalServer_kernel_h

#include <iostream>
#include <string>

namespace Kernel {

enum FUNTIONTYPE
{
    SHAKEHANDSTEP1,
    SHAKEHANDSTEP2,
    SHAKEHANDSTEP3,
    SHAKEHANDSTEP4,
    
    SENDBUFFER, 
    BROADCASTBUFFER,
    
    SERVICEREQUEST,
    SERVERINFOREQUEST,
    REGISTER,
    ALLCLIENTREMOVED,
    TELLSERVEREXIT,
    
    CHANGEACCOUNT,
};

#define ScreenCaptureServiceID 100
#define QQPlatformServiceID     200
    
struct SERVERINFO {
    unsigned int clientCount;
    unsigned int serviceCount;
    unsigned int ID;
};

struct CLIENTINFO
{
    unsigned long ID;
    std::string name;
    std::string headImage;
};
    
class NetObject
{
public:
    virtual unsigned long GetID(void) = 0;
    virtual int WriteData(unsigned long ServiceID, int funtion, void *buffer, unsigned int bufferLen) = 0;
    virtual int ReadData(unsigned long ServiceID, int funtion, void *buffer, unsigned int bufferLen) = 0;
    virtual int NewClientRegister(unsigned long ClientID) = 0;
    virtual int NewServiceRegister(unsigned long ServiceID) = 0;
    virtual int BroadcastData(int funtion, void *buffer, unsigned int bufferLen) = 0;
    virtual int ConnectBreak() = 0;
    virtual int RequestServerInfo(unsigned int ID);
    virtual int RequestServerInfoComeBack(SERVERINFO info);
};

class Server
{
public:
    virtual int AllServiceRemoved();
    virtual int GetServerInfo(SERVERINFO &info);
    virtual int NewClient(CLIENTINFO info);
    virtual int NotifyServerInterface(unsigned int NotifyType, void *buffer, unsigned int bufferLen);
    virtual int RemoveClient(unsigned long ClientID);
    virtual int ChangeAccount();

};

class Service : public NetObject
{
public:
    virtual int WriteData(unsigned long ServiceID, int funtion, void *buffer, unsigned int bufferLen);
    virtual int BroadcastData(int toType, void *buffer, unsigned int bufferLen);
    virtual int TellLocalServerExit();
    virtual int RegisterServiceComeBack(unsigned long ServiceID, bool accept) = 0;
    virtual int ReceiveServiceRequest(unsigned long ServiceID, unsigned long ClientID) = 0;
    virtual int AllClientRemoved() = 0;
    virtual int RequestServerInfo(unsigned int ID);
};

class Client : public NetObject
{
public:
    virtual int WriteData(unsigned long ServiceID, int funtion, void *buffer, unsigned int bufferLen);
    virtual int RequestService(unsigned long ServiceID);
    virtual int BroadcastData(int toType, void *buffer, unsigned int bufferLen);
    virtual int RequestServiceComeBack(unsigned long ServiceID, bool accept) = 0;
    //add by trongxu
    virtual int GetClientInfo(CLIENTINFO &info);
};

// 初始化
int KernelInitialization(void);
// 反初始化
int KernelUnInitialization(void);
// server
int KernelStarServer(int port);
int KernelStopServer(int port);
int KernelRegisterServer(Server *server);
int KernelUnRegisterServer(Server *server);

// service
int KernelServiceConnectServer(char *ip, int port);
int KernelRegisterService(Service *service);
int KernelUnRegisterService(Service *service);

int KernelSendBufferToClient(unsigned int NotifyType, unsigned int userId, const void *buffer, unsigned int bufferLen);

// client
// 发起连接
int KernelClientConnectServer(char *ip, int port);
int KernelRegisterClient(Client *client);

int KernelChangeAccount(Client *client);
    
}// namespace Kernel
#endif
